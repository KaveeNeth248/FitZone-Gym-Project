<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$server = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "fit zone"; 

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
session_start();

// Initialize variables
$search_query = '';

// Handle search request
if (isset($_POST['search'])) {
    $search_query = trim($_POST['search_query']);
}

// Handle clear request
if (isset($_POST['clear'])) {
    $search_query = '';
}

// Fetch reports based on the search query
$sql = "SELECT report_id, report_name, created_at FROM reports";
if ($search_query) {
    $sql .= " WHERE report_name LIKE ?";
}
$stmt = $conn->prepare($sql);
if ($search_query) {
    $search_param = "%" . $conn->real_escape_string($search_query) . "%";
    $stmt->bind_param("s", $search_param);
}
$stmt->execute();
$result = $stmt->get_result();

// Handle form submission to add a new report
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_report'])) {
    $report_name = trim($_POST['report_name']);
    $created_at = date('Y-m-d H:i:s');  // Current timestamp

    // Prepare the insert statement
    $insert_sql = "INSERT INTO reports (report_name, created_at) VALUES (?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    
    if ($insert_stmt) {
        $insert_stmt->bind_param("ss", $report_name, $created_at);
        
        if ($insert_stmt->execute()) {
            $_SESSION['message'] = "Report added successfully!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $_SESSION['error'] = "Error adding report: " . $insert_stmt->error;
        }

        $insert_stmt->close();
    } else {
        $_SESSION['error'] = "Error preparing SQL statement: " . $conn->error;
    }
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM reports WHERE report_id=?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    
    if ($delete_stmt->execute()) {
        $_SESSION['message'] = "Report deleted successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $_SESSION['error'] = "Error deleting report: " . $delete_stmt->error;
    }
    $delete_stmt->close();
}

// Close the database connection (will be reopened later in the script if needed)
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin: auto;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            color: red;
            text-align: center;
        }
        .success {
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>View Reports</h1>

        <!-- Display any session messages -->
        <?php
        if (isset($_SESSION['error'])) {
            echo "<p class='message'>" . $_SESSION['error'] . "</p>";
            unset($_SESSION['error']); // Clear the message after displaying
        }
        if (isset($_SESSION['message'])) {
            echo "<p class='success'>" . $_SESSION['message'] . "</p>";
            unset($_SESSION['message']); // Clear the message after displaying
        }
        ?>

        <!-- Form to add a new report -->
        <form method="POST" action="">
            <h2>Add New Report</h2>
            <input type="text" name="report_name" placeholder="Report Name" required>
            <button type="submit" name="add_report">Add Report</button>
        </form>

        <!-- Search form -->
        <form method="POST" action="">
            <h2>Search Reports</h2>
            <input type="text" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search by report name">
            <button type="submit" name="search">Search</button>
            <button type="submit" name="clear">Clear</button>
        </form>

        <!-- Table to display existing reports -->
        <h2>Existing Reports</h2>
        <table>
            <tr>
                <th>Report ID</th>
                <th>Report Name</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
            <?php
            // Reconnect to the database to fetch updated reports
            $conn = new mysqli($server, $username, $password, $database);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
        

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["report_id"] . "</td>";
                    echo "<td>" . $row["report_name"] . "</td>";
                    echo "<td>" . $row["created_at"] . "</td>";
                    echo "<td><a href='?delete_id=" . $row["report_id"] . "' onclick=\"return confirm('Are you sure you want to delete this report?')\">Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No reports found</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>