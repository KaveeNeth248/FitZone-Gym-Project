<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root"; // Change if necessary
$password = ""; // Change if necessary
$dbname = "fit zone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error_message = "";
$success_message = "";
$search_query = '';

// Handle search request
if (isset($_POST['search'])) {
    $search_query = trim($_POST['search_query']);
}

// Handle clear request
if (isset($_POST['clear'])) {
    $search_query = '';
}

// Retrieve and display all users' records
$sql = "SELECT * FROM users";
if ($search_query) {
    $sql .= " WHERE username LIKE ? OR email LIKE ?";
}
$stmt = $conn->prepare($sql);
if ($search_query) {
    $search_param = "%$search_query%";
    $stmt->bind_param("ss", $search_param, $search_param);
}
$stmt->execute();
$result = $stmt->get_result();

// Handle update request
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    if (!empty($username) && !empty($email)) {
        $stmt = $conn->prepare("UPDATE users SET username=?, email=? WHERE id=?");
        $stmt->bind_param("ssi", $username, $email, $id);
        if ($stmt->execute()) {
            $success_message = "Record updated successfully.";
            header("Location: AdminManagement.php");
            exit();
        } else {
            $error_message = "Error updating record: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error_message = "Please fill in all fields.";
    }
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $success_message = "Record deleted successfully.";
        header("Location: AdminManagement.php");
        exit();
    } else {
        $error_message = "Error deleting record: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management - FitZone Fitness Center</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .message {
            color: red;
            margin-bottom: 20px;
        }
        input, button {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        .button-group {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Admin Management</h1>

    <!-- Display messages -->
    <?php if (!empty($error_message)): ?>
        <p class="message"><?php echo $error_message; ?></p>
    <?php endif; ?>
    <?php if (!empty($success_message)): ?>
        <p class="message" style="color: green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <!-- Search form -->
    <form method="POST" action="AdminManagement.php">
        <input type="text" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search by username or email">
        <button type="submit" name="search">Search</button>
        <button type="submit" name="clear">Clear</button>
    </form>

    <!-- Display users records -->
    <h2>Users Records</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td>
                        <a href="AdminManagement.php?edit_id=<?php echo $row['id']; ?>">Edit</a> |
                        <a href="AdminManagement.php?delete_id=<?php echo $row['id']; ?>" 
                        onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No users records found.</td>
            </tr>
        <?php endif; ?>
    </table>

    <!-- Update form (Only visible when editing) -->
    <?php if (isset($_GET['edit_id'])):
        $edit_id = $_GET['edit_id'];
        $edit_sql = "SELECT * FROM users WHERE id=?";
        $edit_stmt = $conn->prepare($edit_sql);
        $edit_stmt->bind_param("i", $edit_id);
        $edit_stmt->execute();
        $edit_result = $edit_stmt->get_result();
        $edit_row = $edit_result->fetch_assoc();
    ?>
        <h2>Edit User</h2>
        <form method="POST" action="AdminManagement.php">
            <input type="hidden" name="id" value="<?php echo $edit_row['id']; ?>">
            <label>Username:</label>
            <input type="text" name="username" value="<?php echo $edit_row['username']; ?>" required>
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo $edit_row['email']; ?>" required>
            <button type="submit" name="update">Update User</button>
        </form>
    <?php endif; ?>
</div>

<!-- Admin Management Actions -->
<div class="container">
    <h2>Manage Other Entities</h2>

    <div class="button-group">
        <a href="ManageStaff.php"   class="button">Manage Staff</a>
        <a href="ManageTrainer.php" class="button">Manage Trainers</a>
        <a href="ManageCustomers.php"class="button">Manage Customers</a>

    </div>

        <div class="button-group">
        <a href="ManageClasses.php" class="button">Manage class signUp</a>
        <a href="ViewReports.php"   class="button">View Reports</a>
        <a href="ManageMessages.php"class="button">Manage Messages</a>
    </div>
</div>

</body>
</html>