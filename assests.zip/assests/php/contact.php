<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fit zone";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Simple validation
    if (!empty($name) && filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($message)) {
        // Prepare the SQL statement to insert the message
        $sql = "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $name, $email, $message);

            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Thank you, $name! Your message has been sent.";
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                $_SESSION['error_message'] = "Error saving your message. Please try again.";
            }
            $stmt->close();
        }
    } else {
        $_SESSION['error_message'] = "Please fill in all fields correctly.";
    }
}

// Display any success or error messages
$success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';

// Clear messages after displaying
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - FitZone Fitness Center</title>
    <link rel="stylesheet" href="C:/xampp/htdocs/HD10_KAVEESHA/css/mywebcontact.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <section id="contact" class="contact-section">
        <h2>Contact Us</h2>
        <div class="contact-content">
            <div class="contact-info">
                <h3>Get in Touch with FitZone</h3>
                <p>Have questions or need more information about our gym, trainers, or classes? We're here to help! Fill out the form below or reach out via social media.</p>
                <ul>
                    <li><strong>Email:</strong> info@fitzone.com</li>
                    <li><strong>Phone:</strong> (+94) 789877678</li>
                    <li><strong>Address:</strong> 67/1, Athulgalpura, Kurunagala, Sri Lanka</li>
                </ul>
            </div>
            <!-- Contact Form -->
            <div class="contact-form">
                <?php if ($success_message): ?>
                    <div class="success-message"><?php echo $success_message; ?></div>
                <?php endif; ?>
                <?php if ($error_message): ?>
                    <div class="error-message"><?php echo $error_message; ?></div>
                <?php endif; ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <label for="name">Full Name:</label>
                    <input type="text" id="name" name="name" placeholder="Your Name" required>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Your Email" required>

                    <label for="message">Message:</label>
                    <textarea id="message" name="message" placeholder="Your Message" required></textarea>

                    <button type="submit" class="btn submit-btn">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <div class="map-container">
        <h3>Visit Us</h3>
        <div class="map-responsive">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3154.1234567890123!2d144.95373631568094!3d-37.81627997975178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0x5045675218ce7e33!2s67%2F1%2C+Athulgalpura%2C+Kurunagala%2C+Sri+Lanka!5e0!3m2!1sen!2slk!4v1639923382011!5m2!1sen!2slk"
                width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="footer-content">
            <div class="social-icons">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i></a>
            </div>
            <p>&copy; 2024 FitZone Fitness Center. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
<style>
    
.contact-section {
    padding: 50px 20px;
    color: #333;
    text-align: center;
    background-color: antiquewhite;
    
}


.contact-section h2 {
    font-size: 36px;
    margin-bottom: 20px;
    color: #00bfff;
}

.contact-content {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: center;
}

.contact-info-form {
    flex: 1;
    min-width: 300px;
}

.contact-info {
    text-align: left;
}

.contact-info h3 {
    font-size: 24px;
    color: #008fbd;
}

.contact-info ul {
    list-style: none;
    padding: 0;
}

.contact-info ul li {
    font-size: 18px;
    margin-bottom: 10px;
}

/* Contact Form Styles */
.contact-form {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.contact-form form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.contact-form input, .contact-form textarea {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
    outline: none;
    transition: border-color 0.3s ease;
}

.contact-form input:focus, .contact-form textarea:focus {
    border-color: #00bfff;
}

.contact-form textarea {
    resize: none;
    height: 150px;
}

.contact-form .submit-btn {
    background-color: #00bfff;
    color: white;
    padding: 12px 20px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.contact-form .submit-btn:hover {
    background-color: #008fbd;
    transform: scale(1.05);
}

/* Map Styles */
.map-container {
    flex: 1;
    min-width: 300px;
}

.map-responsive {
    position: relative;
    overflow: hidden;
    padding-bottom: 56.25%; /* Aspect ratio 16:9 */
    height: 0;
}

.map-responsive iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

/* Footer Styles */
.footer {
    background-color: #000;
    color: #fff;
    padding: 20px;
    text-align: center;
}

.footer .footer-content {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.footer .social-icons {
    margin-bottom: 15px;
}

.footer .social-icons a {
    color: #00bfff;
    font-size: 24px;
    margin: 0 10px;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer .social-icons a:hover {
    color: #008fbd;
}

.footer p {
    font-size: 16px;
    margin-top: 10px;
    color: #ccc;
}
body {
    background-image: url('images\imm11');
    background-size: cover; /* Ensures the image covers the whole page */
    background-position: center; /* Centers the background image */
    background-repeat: no-repeat; /* Prevents the background from repeating */
}
    </style>