<?php
// Start a session
session_start();

// Database connection parameters
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "fit zone";

// Initialize variables for errors
$name = $email = $membership_plan = "";
$name_err = $email_err = $membership_plan_err = "";
$success_message = $db_err = "";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your full name.";
    } else {
        $name = htmlspecialchars(trim($_POST["name"]));
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } elseif (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        $email = htmlspecialchars(trim($_POST["email"]));

        // Check if the email already exists in the database
        $sql = "SELECT * FROM users WHERE email = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $email_err = "This email is already registered.";
            }
            $stmt->close();
        } else {
            $db_err = "Error: Could not prepare the email check query. " . $conn->error;
        }
    }

    // Validate membership plan
    if (empty(trim($_POST["membership-plan"]))) {
        $membership_plan_err = "Please select a membership plan.";
    } else {
        $membership_plan = htmlspecialchars(trim($_POST["membership-plan"]));
    }

    // If there are no errors, insert the data into the database
    if (empty($name_err) && empty($email_err) && empty($membership_plan_err)) {
        $sql = "INSERT INTO users (username, email, membership_plan) VALUES (?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $name, $email, $membership_plan);
            if ($stmt->execute()) {
                $success_message = "Registration successful! Welcome, " . htmlspecialchars($name) . ".";
            } else {
                $db_err = "Error: Could not execute query. " . $stmt->error;
            }
            $stmt->close();
        } else {
            $db_err = "Error: Could not prepare the statement. " . $conn->error;
        }
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - FitZone Fitness Center</title>
    <link rel="stylesheet" href="C:/xampp/htdocs/HD10_KAVEESHA/css/myweb.css">
</head>
<body>

<header>
    <div class="container">
        <div class="logo">
            <h1>Welcome To the Registering Plan</h1>
        </div>
    </div>
</header>

<section class="registration" id="register">
    <div class="container">
        <h2>Register for Membership</h2>

        <!-- Display success message -->
        <?php if (!empty($success_message)): ?>
            <p style="color: green; font-weight: bold;"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <!-- Display error message if any -->
        <?php if (!empty($db_err)): ?>
            <div class="error"><?php echo $db_err; ?></div>
        <?php endif; ?>

        <form class="registration-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
            <span class="error"><?php echo $name_err; ?></span>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            <span class="error"><?php echo $email_err; ?></span>

            <label for="membership-plan">Choose a Plan:</label>
            <select id="membership-plan" name="membership-plan" required>
                <option value="">Select a plan</option>
                <option value="basic" <?php echo ($membership_plan == 'basic') ? 'selected' : ''; ?>>Basic Plan</option>
                <option value="standard" <?php echo ($membership_plan == 'standard') ? 'selected' : ''; ?>>Standard Plan</option>
                <option value="premium" <?php echo ($membership_plan == 'premium') ? 'selected' : ''; ?>>Premium Plan</option>
            </select>
            <span class="error"><?php echo $membership_plan_err; ?></span>

            <button type="submit" class="btn-cta">Register Now</button>
        </form>
    </div>
</section>

<footer class="footer">
    <div class="footer-content">
        <p>&copy; 2024 FitZone Fitness Center. All rights reserved.</p>
    </div>
</footer>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }

    header {
        background-color: #333;
        color: #fff;
        padding: 10px 0;
    }

    header .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .registration {
        background-color: #fff;
        padding: 20px;
        max-width: 600px;
        margin: 50px auto;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .registration h2 {
        margin-bottom: 20px;
    }

    .registration-form label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    .registration-form input[type="text"],
    .registration-form input[type="email"],
    .registration-form select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .registration-form button {
        background-color: #28a745;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }

    .registration-form button:hover {
        background-color: #218838;
    }

    footer {
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 10px 0;
        position: relative;
        bottom: 0;
        width: 100%;
    }

    .error {
        color: red;
        font-size: 0.9em;
    }
</style>

</body>
</html>