<?php
// Enable error reporting for debugging (turn off in production)
ini_set('display_errors', 0); // Disable error display
ini_set('log_errors', 1);     // Enable error logging to a file
error_reporting(E_ALL);

// Database connection
$server = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "fit zone"; 

$conn = new mysqli($server, $username, $password, $database);

// Check database connection
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    die("Connection failed. Please try again later.");
}

// Assume staff_id is retrieved from session or another secure source (for testing, we are hardcoding it)
$staff_id = 1; // Replace this with dynamic staff ID retrieval logic if needed

// Initialize messages
$success_message = '';
$error_message = '';

// Fetch current staff details
$staff_query = "SELECT id, name, email, specialty FROM staff WHERE id = ?";
if ($stmt = $conn->prepare($staff_query)) {
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $staff = $result->fetch_assoc();
    } else {
        $error_message = "Staff not found.";
    }
    $stmt->close();
} else {
    $error_message = "Error fetching staff details.";
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $specialty = htmlspecialchars(trim($_POST['specialty']));

    if (empty($name) || empty($email) || empty($specialty)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Update staff profile in the database
        $update_query = "UPDATE staff SET name = ?, email = ?, specialty = ? WHERE id = ?";
        if ($stmt = $conn->prepare($update_query)) {
            $stmt->bind_param("sssi", $name, $email, $specialty, $staff_id);
            if ($stmt->execute()) {
                $success_message = "Profile updated successfully!";
                // Update local $staff array with the new data
                $staff['name'] = $name;
                $staff['email'] = $email;
                $staff['specialty'] = $specialty;
            } else {
                $error_message = "Error updating profile.";
            }
            $stmt->close();
        } else {
            $error_message = "Error preparing statement for profile update.";
        }
    }
}

// Fetch users from the users table
$user_query = "SELECT id, username, email, membership_plan, created_at FROM users";
$user_result = $conn->query($user_query);

// Fetch bookings from the bookings table
$booking_query = "
    SELECT id AS booking_id, name, email, phone, trainer, session_date, created_at 
    FROM bookings
    ORDER BY session_date DESC";
$booking_result = $conn->query($booking_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            width: 80%;
            max-width: 1200px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color:blue;
            color: white;
        }
        form {
            width: 100%;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color:purple;
        }
        .message {
            margin-top: 10px;
            color: red;
        }
        .success-message {
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Staff Dashboard</h1>

        <!-- Display error or success messages -->
        <?php if ($error_message): ?>
            <p class="message"><?php echo $error_message; ?></p>
        <?php elseif ($success_message): ?>
            <p class="success-message"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <!-- Staff Profile Form -->
        <h2>Your Profile</h2>
        <form method="POST" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($staff['name']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($staff['email']); ?>" required>

            <label for="specialty">Specialty:</label>
            <input type="text" id="specialty" name="specialty" value="<?php echo htmlspecialchars($staff['specialty']); ?>" required>

            <button type="submit" name="update_profile">Update Profile</button>
        </form>

        <!-- Registered Users Table -->
        <h2>Registered Users</h2>
        <?php if ($user_result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Membership Plan</th>
                    <th>Created At</th>
                </tr>
                <?php while ($user = $user_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['membership_plan']); ?></td>
                        <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No registered users found.</p>
        <?php endif; ?>

        <!-- Bookings Table -->
        <h2>Bookings</h2>
        <?php if ($booking_result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Booking ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Trainer</th>
                    <th>Session Date</th>
                    <th>Created At</th>
                </tr>
                <?php while ($booking = $booking_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($booking['booking_id']); ?></td>
                        <td><?php echo htmlspecialchars($booking['name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['email']); ?></td>
                        <td><?php echo htmlspecialchars($booking['phone']); ?></td>
                        <td><?php echo htmlspecialchars($booking['trainer']); ?></td>
                        <td><?php echo htmlspecialchars($booking['session_date']); ?></td>
                        <td><?php echo htmlspecialchars($booking['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No bookings found.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Free result sets and close database connection
$user_result->free();
$booking_result->free();
$conn->close();
?>