<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fit zone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = "";
$success_message = "";
$search_query = '';

// Handle search request
if (isset($_POST['search'])) {
    $search_query = trim($_POST['search_query']);
}

// Handle clear request
if (isset($_POST['clear'])) {
    $search_query = '';
}

// Handle add customer request
if (isset($_POST['add_customer'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

    // Validate input
    if (!empty($name) && !empty($email)) {
        // Sanitize input to prevent XSS
        $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        
        // Prepare the SQL query to prevent SQL Injection
        $stmt = $conn->prepare("INSERT INTO customers (name, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $email);

        // Execute and check if the insert was successful
        if ($stmt->execute()) {
            $success_message = "Customer added successfully.";
        } else {
            $error_message = "Error adding customer: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error_message = "Please fill in all fields.";
    }
}

// Retrieve customer records based on search query
$sql = "SELECT * FROM customers";
if ($search_query) {
    $sql .= " WHERE name LIKE ? OR email LIKE ?";
}
$stmt = $conn->prepare($sql);
if ($search_query) {
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
}
$stmt->execute();
$result = $stmt->get_result();

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare and execute delete query
    $stmt = $conn->prepare("DELETE FROM customers WHERE customer_id=?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $success_message = "Customer deleted successfully.";
        header("Location: ManageCustomers.php");
        exit();
    } else {
        $error_message = "Error deleting customer: " . $stmt->error;
    }
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Customers - FitZone Fitness Center</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .message {
            color: red;
            margin-bottom: 20px;
        }
        .success {
            color: green;
        }
        input, button {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        .table-container {
            margin-top: 30px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Manage Customers</h1>

    <!-- Display success or error message -->
    <?php if (!empty($error_message)): ?>
        <p class="message"><?php echo $error_message; ?></p>
    <?php endif; ?>
    <?php if (!empty($success_message)): ?>
        <p class="message success"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <!-- Add Customer Form -->
    <h2>Add New Customer</h2>
    <form method="POST" action="ManageCustomers.php">
        <input type="text" name="name" placeholder="Customer Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit" name="add_customer">Add Customer</button>
    </form>

    <!-- Search Form -->
    <h3>Search Customers</h3>
    <form method="POST" action="ManageCustomers.php">
        <input type="text" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search by name or email">
        <button type="submit" name="search">Search</button>
        <button type="submit" name="clear">Clear</button>
    </form>

    <!-- Customer Table -->
    <div class="table-container">
        <h2>Customer Records</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['customer_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>
                            <a href="ManageCustomers.php?delete_id=<?php echo $row['customer_id']; ?>" onclick="return confirm('Are you sure you want to delete this customer?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No customer records found.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

</body>
</html>