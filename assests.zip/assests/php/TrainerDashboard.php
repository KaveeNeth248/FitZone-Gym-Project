<?php
// Start session to track login status
session_start();

// Check if the trainer is logged in
if (!isset($_SESSION['id'])) {
    // If not logged in, redirect to login page
    header("Location: TrainerReg.php");
    exit;
}

// Get trainer details from the session
$trainer_id = $_SESSION['id']; // Get trainer ID from session
$trainer_name = $_SESSION['name']; // Get trainer name from session

// Database connection
$server = "localhost";
$username = "root";
$password = "";
$database = "fit zone";

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch booking details for the logged-in trainer (using trainer's name instead of ID)
$booking_details = [];
$sql = "SELECT b.id, b.name, b.email, b.phone, b.session_date, b.created_at 
        FROM bookings b
        JOIN trainers t ON b.trainer = t.name
        WHERE t.name = ? 
        ORDER BY b.session_date DESC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("s", $trainer_name); // Bind the trainer's name to the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch all bookings into an array
    while ($row = $result->fetch_assoc()) {
        $booking_details[] = $row;
    }

    $stmt->close(); // Close the prepared statement
} else {
    echo "Error preparing SQL query: " . $conn->error;
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Dashboard</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 50px;
        }

        h1 {
            color: #333;
        }

        .welcome {
            margin-top: 20px;
            color: green;
        }

        .booking-table {
            margin-top: 30px;
            width: 100%;
            border-collapse: collapse;
        }

        .booking-table th, .booking-table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        .booking-table th {
            background-color: #f2f2f2;
        }

        .logout-button {
            margin-top: 30px;
            padding: 10px 20px;
            background-color: red;
            color: white;
            border: none;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
    <h1>Welcome to the Trainer Dashboard</h1>
    <p class="welcome">Hello, <?php echo htmlspecialchars($trainer_name); ?>! You are logged in.</p>

    <h2>Your Bookings</h2>

    <!-- Display the booking details in a table -->
    <?php if (count($booking_details) > 0): ?>
        <table class="booking-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Session Date</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($booking_details as $booking): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($booking['id']); ?></td>
                        <td><?php echo htmlspecialchars($booking['name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['email']); ?></td>
                        <td><?php echo htmlspecialchars($booking['phone']); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($booking['session_date'])); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($booking['created_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No bookings found for you.</p>
    <?php endif; ?>
</body>
</html>