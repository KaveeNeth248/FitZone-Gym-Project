<?php
// Start the session
session_start();

// Database connection
$server = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "fit zone"; 

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the posted values
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Input validation
    if (empty($email) || empty($password)) {
        $error_message = "Please enter both email and password.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Prepare SQL query to fetch trainer's data by email
        $sql = "SELECT id, name, email, password FROM trainers WHERE email = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            // Check if the trainer exists
            if ($result->num_rows === 1) {
                $row = $result->fetch_assoc();

                // Verify password
                if (password_verify($password, $row['password'])) {
                    // Password is correct, set session variables
                    $_SESSION['id'] = $row['id']; // Trainer's ID
                    $_SESSION['name'] = $row['name']; // Trainer's name
                    $_SESSION['email'] = $row['email']; // Trainer's email

                    // Redirect to the trainer dashboard
                    header("Location: TrainerDashboard.php");
                    exit;
                } else {
                    $error_message = "Incorrect password.";
                }
            } else {
                $error_message = "No trainer found with that email.";
            }

            $stmt->close(); // Close prepared statement
        } else {
            $error_message = "Error: Could not prepare the SQL statement.";
        }
    }
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Login - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 10px;
            color: red;
        }

        .success-message {
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Trainer Login</h1>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>

            <!-- Display error or success messages -->
            <?php
            if (!empty($error_message)) {
                echo "<p class='message'>$error_message</p>";
            } elseif (!empty($success_message)) {
                echo "<p class='success-message'>$success_message</p>";
            }
            ?>
        </form>
    </div>
</body>
</html>