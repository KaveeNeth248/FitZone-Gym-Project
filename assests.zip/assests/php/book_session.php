<?php
// Database connection details
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "fit zone"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $trainer = $_POST['trainer'];
    $session_date = $_POST['session_date'];
    $created_at = date('Y-m-d H:i:s'); // For demonstration, set created_at to current date and time

    // Validate inputs (you can extend this)
    if (!empty($name) && !empty($email) && !empty($phone) && !empty($session_date)) {
        // Insert booking details into the database
        $stmt = $conn->prepare("INSERT INTO bookings (name, email, phone, trainer, session_date, created_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $email, $phone, $trainer, $session_date, $created_at);

        if ($stmt->execute()) {
            // Booking successfully saved, display success message
            echo "<p>Thank you, $name. Your session with $trainer has been booked for $session_date!</p>";
        } else {
            echo "<p>Error: Unable to save your booking. Please try again later.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Please fill all the required fields.</p>";
    }
} else {
    // Get the trainer name from the URL or set a default
    $trainer = isset($_GET['trainer']) ? $_GET['trainer'] : 'Unknown Trainer';
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Session</title>
    <link rel="stylesheet" href="C:\xampp\htdocs\HD10_KAVEESHA\css\mywebTrainer.css">
</head>
<body>
    <h1>Book a Session with <?php echo $trainer; ?></h1>
    <form action="book_session.php" method="POST">
        <input type="hidden" name="trainer" value="<?php echo $trainer; ?>">
        
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="phone">Your Phone:</label>
        <input type="text" id="phone" name="phone" required>
        
        <label for="session_date">Preferred Session Date:</label>
        <input type="date" id="session_date" name="session_date" required>

        <label for="Trainers">Choose a Trainer:</label>
        <select id="trainer" name="trainer" required>
            <option value="John Doe">John Doe</option>
            <option value="Olive Stein">Olive Stein</option>
            <option value="Harvey Karols">Harvey Karols</option>
        </select>
        
        <button type="submit">Book Now</button>
    </form>

    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

h1 {
    text-align: center;
    margin: 20px 0;
}

form {
    background-color: #fff;
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

input[type="text"],
input[type="email"],
input[type="date"],
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background-color: #28a745;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    font-size: 16px;
}

button:hover {
    background-color: #218838;
}

p {
    text-align: center;
    font-weight: bold;
    color:blue;
}
        <style>
</body>
</html>