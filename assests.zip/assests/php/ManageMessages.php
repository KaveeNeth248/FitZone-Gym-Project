<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fit zone";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error_message = "";
$success_message = "";

// Handle response update
if (isset($_POST['respond'])) {
    $id = $_POST['id'];
    $response = htmlspecialchars(trim($_POST['response']));
    
    if (!empty($response)) {
        // Update the message with the admin's response
        $stmt = $conn->prepare("UPDATE contact_messages SET response=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->bind_param("si", $response, $id);
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Response sent successfully.";
            header("Location: ManageMessages.php"); // Redirect to refresh the page
            exit();
        } else {
            $_SESSION['error_message'] = "Error saving your response. Please try again.";
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Response cannot be empty.";
    }
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM contact_messages WHERE id=?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Message deleted successfully.";
        header("Location: ManageMessages.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error deleting the message. Please try again.";
    }
    $stmt->close();
}

// Fetch all messages
$sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Messages - Admin Panel</title>
    <style>
        /* Basic styling for the manage messages page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .messages-section {
            margin: 20px;
        }

        h2 {
            color: #0056b3;
        }

        .success-message, .error-message {
            padding: 10px;
            margin-bottom: 20px;
            color: #fff;
            border-radius: 5px;
        }

        .success-message {
            background-color: #28a745;
        }

        .error-message {
            background-color: #dc3545;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f1f1f1;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <section id="manage-messages" class="messages-section">
        <h2>Manage Contact Messages</h2>

        <!-- Display success or error messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message"><?php echo $_SESSION['success_message']; ?></div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="error-message"><?php echo $_SESSION['error_message']; ?></div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Message Table -->
        <table class="message-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo nl2br($row['message']); ?></td>
                            <td>
                                <a href="ManageMessages.php?view_id=<?php echo $row['id']; ?>">View</a> |
                                <a href="ManageMessages.php?delete_id=<?php echo $row['id']; ?>" 
                                    onclick="return confirm('Are you sure you want to delete this message?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No messages found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Respond to a message -->
        <?php if (isset($_GET['view_id'])):
            $view_id = $_GET['view_id'];
            $view_sql = "SELECT * FROM contact_messages WHERE id=?";
            $view_stmt = $conn->prepare($view_sql);
            $view_stmt->bind_param("i", $view_id);
            $view_stmt->execute();
            $view_result = $view_stmt->get_result();
            $message = $view_result->fetch_assoc();
        ?>
        <h2>View and Respond to Message</h2>
        <form method="POST" action="ManageMessages.php">
            <input type="hidden" name="id" value="<?php echo $message['id']; ?>">
            <p><strong>From:</strong> <?php echo $message['name']; ?> (<?php echo $message['email']; ?>)</p>
            <p><strong>Message:</strong></p>
            <p><?php echo nl2br($message['message']); ?></p>
            <label for="response">Response:</label>
            <textarea name="response" id="response" rows="5" required><?php echo htmlspecialchars($message['response']); ?></textarea><br><br>
            <button type="submit" name="respond">Send Response</button>
        </form>
        <?php endif; ?>
    </section>
</body>
</html>