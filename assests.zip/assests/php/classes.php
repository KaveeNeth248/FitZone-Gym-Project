<?php
// Start the session if needed
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Change if necessary
$password = ""; // Change if necessary
$dbname = "fit zone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle class sign-up form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['class_signup'])) {
    $class_name = htmlspecialchars(trim($_POST['class_name']));
    $user_name = htmlspecialchars(trim($_POST['user_name']));
    $email = htmlspecialchars(trim($_POST['email']));

    $stmt = $conn->prepare("INSERT INTO class_signups (class_name, user_name, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $class_name, $user_name, $email);

    if ($stmt->execute()) {
        echo "<script>alert('Successfully signed up for $class_name!');</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Handle newsletter subscription form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['newsletter_signup'])) {
    $email = htmlspecialchars(trim($_POST['email']));

    $stmt = $conn->prepare("INSERT INTO newsletter_subscriptions (email) VALUES (?)");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        echo "<script>alert('Thank you for subscribing to our newsletter!');</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness Center Classes</title>
    <link rel="stylesheet"  href="css/mywebclasses.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <h1 class="logo">FitZone Fitness Center</h1>
            <nav>
                <ul>
                    <li><a href="#classes">Classes</a></li>
                    <li><a href="mywebabout.html">About</a></li>
                    <li><a href="mywebcontact.html">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="classes" id="classes">
        <h2>Our Classes</h2>
        <div class="class-cards">
            <!-- Example Class Card -->
            <div class="class-card">
                <h3>Yoga</h3>
                <p>Find your balance and peace with our relaxing yoga sessions.</p>
                <form method="POST" action="">
                    <input type="hidden" name="class_name" value="Yoga">
                    <label for="name">Name:</label>
                    <input type="text" name="user_name" required>
                    <label for="email">Email:</label>
                    <input type="email" name="email" required>
                    <button type="submit" name="class_signup" class="btn-signup">Sign Up</button>
                </form>
            </div>

            <!-- Example Class Card -->
            <div class="class-card">
                <h3>Zumba</h3>
                <p>Dance your way to fitness in our energetic Zumba classes.</p>
                <form method="POST" action="">
                    <input type="hidden" name="class_name" value="Zumba">
                    <label for="name">Name:</label>
                    <input type="text" name="user_name" required>
                    <label for="email">Email:</label>
                    <input type="email" name="email" required>
                    <button type="submit" name="class_signup" class="btn-signup">Sign Up</button>
                </form>
            </div>

            <div class="class-card">
                <h3>Kickboxing</h3>
                <p>Find your balance and peace with our relaxing yoga sessions.</p>
                <form method="POST" action="">
                    <input type="hidden" name="class_name" value="Kickboxing">
                    <label for="name">Name:</label>
                    <input type="text" name="user_name" required>
                    <label for="email">Email:</label>
                    <input type="email" name="email" required>
                    <button type="submit" name="class_signup" class="btn-signup">Sign Up</button>
                </form>
            </div>

            <div class="class-card">
                <h3>Strength Training</h3>
                <p>Find your balance and peace with our relaxing yoga sessions.</p>
                <form method="POST" action="">
                    <input type="hidden" name="class_name" value="Strength Training">
                    <label for="name">Name:</label>
                    <input type="text" name="user_name" required>
                    <label for="email">Email:</label>
                    <input type="email" name="email" required>
                    <button type="submit" name="class_signup" class="btn-signup">Sign Up</button>
                </form>
            </div>

            <!-- Add more classes similarly -->
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="footer-content">
            <div class="social-icons">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i></a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe to our newsletter for the latest fitness tips and updates!</p>
                <form method="POST" action="">
                    <input type="email" name="email" placeholder="Your email" required>
                    <button type="submit" name="newsletter_signup">Subscribe</button>
                </form>
            </div>
        </div>
        <p>&copy; 2024 FitZone Fitness Center. All rights reserved.</p>
    </footer>

</body>
</html>

<style>
/* Global Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
}

body {
    background-color: #f2f2f2;
    color: #333;
}

/* Header Styles */
header {
    background-color: #1e1e1e;
    color: #fff;
    padding: 20px 0;
}

header .logo {
    font-size: 32px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 2px;
    color: #00d1b2;
    text-align: center;
}

nav ul {
    list-style: none;
    display: flex;
    justify-content: center;
    gap: 25px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s;
}

nav ul li a:hover {
    color: #00d1b2;
}

/* Hero Section with Background Video */
.hero {
    position: relative;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    overflow: hidden;
}

.hero-video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
}

.hero-content {
    position: relative;
    text-align: center;
    z-index: 1;
}

.hero h2 {
    font-size: 50px;
    text-transform: uppercase;
    letter-spacing: 3px;
    margin-bottom: 20px;
}

.hero p {
    font-size: 20px;
    max-width: 600px;
    margin: 0 auto 30px;
}

.btn-cta {
    padding: 15px 30px;
    background-color: #00d1b2;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 18px;
    transition: background-color 0.3s;
}

.btn-cta:hover {
    background-color: #00b89f;
}

/* Classes Section */
.classes {
    padding: 80px 0;
    text-align: center;
}

.classes h2 {
    font-size: 36px;
    margin-bottom: 40px;
    color: #1e1e1e;
}

.class-cards {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 20px;
}

.class-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: transform 0.3s;
    width: 300px;
    cursor: pointer;
}

.class-card:hover {
    transform: scale(1.05);
}

.class-image {
    width: 100%;
    height: auto;
}

.class-card h3 {
    font-size: 24px;
    margin: 15px 0;
    color: #00d1b2;
}

.class-card p {
    font-size: 16px;
    color: #666;
    padding: 0 15px 15px;
}

.btn-signup {
    display: inline-block;
    padding: 10px 20px;
    background-color: #00d1b2;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    margin: 15px 0;
    transition: background-color 0.3s;
}

.btn-signup:hover {
    background-color: #00b89f;
}

/* Dialog Box Styles */
.dialog {
    display: none; /* Hidden by default */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    justify-content: center;
    align-items: center;
}

.dialog-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    width: 400px;
    text-align: center;
    position: relative;
    animation: fadeIn 0.5s ease;
}

.dialog-content h3 {
    margin-bottom: 15px;
}

.dialog-content .close {
    position: absolute;
    top: 10px;
    right: 15px;
    cursor: pointer;
    font-size: 20px;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* Footer */
footer {
    background-color: #1e1e1e;
    color: #fff;
    text-align: center;
   padding: 20px;
}
</style>

<?php
// Close the database connection
$conn->close();
?>

