<?php
// Start the session if needed
session_start();

// Initialize error message variable
$error_message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if username and password fields are set and not empty
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        // Sanitize and assign form inputs
        $inputUsername = trim($_POST['username']);
        $inputPassword = trim($_POST['password']);

        // Hardcoded admin credentials (for this case)
        $adminUsername = "admin";
        $adminPassword = "123456"; // Plain password for comparison (not recommended for production)
        $adminEmail = "admin@gmail.com";

        // Check if username and password match
        if ($inputUsername === $adminUsername && $inputPassword === $adminPassword) {
            // Successful login, set session variables and redirect to admin management page
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $inputUsername;
            header("Location: AdminManagement.php");
            exit();
        } else {
            // Invalid username or password
            $error_message = "Invalid username or password.";
        }
    } else {
        // Display error if form fields are not set
        $error_message = "Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            width: 320px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .error-message {
            color: red;
            margin-top: 10px;
        }

        form {
            display: flex;
            flex-direction: column;
            width: 100%;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Login</h1>
        <form action="AdminLogin.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
            
            <?php
            if (isset($error_message)) {
                echo "<p class='error-message'>" . htmlspecialchars($error_message) . "</p>";
            }
            ?>
        </form>
    </div>
</body>
</html>