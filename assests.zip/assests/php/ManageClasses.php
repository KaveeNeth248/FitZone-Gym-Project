<?php
// Database connection
$server = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "fit zone"; 

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start(); 

// Initialize variables
$search_query = '';
$message = '';
$edit_id = '';
$class_name = '';
$user_name = '';
$email = '';

// Handle search request
if (isset($_POST['search'])) {
    $search_query = trim($_POST['search_query']);
}

// Handle clear request
if (isset($_POST['clear'])) {
    $search_query = '';
}

// Fetch class signups based on the search query
$sql = "SELECT id, class_name, user_name, email FROM class_signups";
if ($search_query) {
    $sql .= " WHERE class_name LIKE ? OR user_name LIKE ? OR email LIKE ?";
}
$stmt = $conn->prepare($sql);
if ($search_query) {
    $search_param = "%" . $conn->real_escape_string($search_query) . "%";
    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
}
$stmt->execute();
$result = $stmt->get_result();

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM class_signups WHERE id=?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    
    if ($delete_stmt->execute()) {
        $message = "Record deleted successfully!";
        header("Location: ManageClasses.php"); // Redirect after delete
        exit;
    } else {
        $message = "Error deleting record: " . $delete_stmt->error;
    }
    $delete_stmt->close();
}

// Handle edit request (fetch the class details for the selected record)
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $edit_sql = "SELECT * FROM class_signups WHERE id = ?";
    $edit_stmt = $conn->prepare($edit_sql);
    $edit_stmt->bind_param("i", $edit_id);
    $edit_stmt->execute();
    $edit_result = $edit_stmt->get_result();

    if ($edit_result->num_rows > 0) {
        $row = $edit_result->fetch_assoc();
        $class_name = $row['class_name'];
        $user_name = $row['user_name'];
        $email = $row['email'];
    }
    $edit_stmt->close();
}

// Handle form submission to update record
if (isset($_POST['update'])) {
    $class_name = trim($_POST['class_name']);
    $user_name = trim($_POST['user_name']);
    $email = trim($_POST['email']);

    if ($class_name && $user_name && $email) {
        $update_sql = "UPDATE class_signups SET class_name = ?, user_name = ?, email = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssi", $class_name, $user_name, $email, $edit_id);

        if ($update_stmt->execute()) {
            $message = "Record updated successfully!";
            header("Location: ManageClasses.php"); // Redirect after update
            exit;
        } else {
            $message = "Error updating record: " . $update_stmt->error;
        }
        $update_stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Class Signups - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            max-width: 800px;
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            text-align: center;
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        td {
            background-color: #f9f9f9;
        }
        .no-data {
            text-align: center;
            color: #777;
            padding: 20px;
        }
        .message {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"], input[type="email"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 80%;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Class Signups</h1>
        <!-- Display messages -->
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        
        <!-- Search form -->
        <form method="POST" action="">
            <input type="text" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search by class name, username, or email">
            <button type="submit" name="search">Search</button>
            <button type="submit" name="clear">Clear</button>
        </form>

        <table>
            <tr>
                <th>Class</th>
                <th>Username</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["class_name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["user_name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["email"]); ?></td>
                        <td>
                            <!-- Edit button (using GET for the edit_id) -->
                            <a href="?edit_id=<?php echo $row['id']; ?>">Edit</a> |
                            <a href="ManageClasses.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                        </td>
                    </tr>

                    <!-- Inline Edit Form (only show for the selected record) -->
                    <?php if (isset($_GET['edit_id']) && $_GET['edit_id'] == $row['id']): ?>
                        <tr>
                            <td colspan="4">
                                <form method="POST" action="">
                                    <input type="text" name="class_name" value="<?php echo htmlspecialchars($row['class_name']); ?>" placeholder="Class Name" required>
                                    <input type="text" name="user_name" value="<?php echo htmlspecialchars($row['user_name']); ?>" placeholder="Username" required>
                                    <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" placeholder="Email" required>
                                    <button type="submit" name="update">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="no-data">No records found</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>