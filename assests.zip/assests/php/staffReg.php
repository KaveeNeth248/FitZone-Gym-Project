<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$server = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "fit zone"; 

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize variables for success and error messages
$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Use htmlspecialchars to prevent XSS attacks and trim to remove unnecessary whitespace
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $specialty = htmlspecialchars(trim($_POST['specialty']));

    // Basic validation
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password) || empty($specialty)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error_message = "Password must be at least 8 characters long.";
    } else {
        // Check if email already exists in the staff table
        $sql = "SELECT * FROM staff WHERE email = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error_message = "This email is already registered.";
            } else {
                // If no errors, proceed with registration
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert the new staff member into the database
                $insert_sql = "INSERT INTO staff (name, email, password_hash, specialty) VALUES (?, ?, ?, ?)";
                if ($insert_stmt = $conn->prepare($insert_sql)) {
                    $insert_stmt->bind_param("ssss", $name, $email, $hashed_password, $specialty);
                    
                    if ($insert_stmt->execute()) {
                        $success_message = "Registration successful! You can now login.";
                    } else {
                        $error_message = "Error: Could not register the staff member. Error details: " . $insert_stmt->error;
                    }
                    
                    $insert_stmt->close(); // Close the insert statement
                } else {
                    $error_message = "Error preparing insert statement: " . $conn->error;
                }
            }
            $stmt->close();
        } else {
            $error_message = "Error preparing SQL statement: " . $conn->error;
        }
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 10px;
            color: red;
        }

        .success-message {
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Staff Registration</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <label for="specialty">Specialty:</label>
            <input type="text" id="specialty" name="specialty" required>

            <button type="submit">Register</button>
        </form>
        
        <a href="http://localhost/HD10_KAVEESHA/assests/php/staffLogin.php">Go to Login Page</a>

        <!-- Display error or success messages -->
        <?php
        if (!empty($error_message)) {
            echo "<p class='message'>$error_message</p>";
        } elseif (!empty($success_message)) { 
            echo "<p class='success-message'>$success_message</p>";
        }
        ?>
    </div>
</body>
</html>