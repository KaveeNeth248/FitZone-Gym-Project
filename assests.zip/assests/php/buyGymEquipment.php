<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
$server = "localhost";
$username = "root";
$password = "";
$database = "fit zone";

$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available gym equipment for display in dropdown
$equipment_options = [];
$sql = "SELECT equipment_id, name, price FROM equipments";
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $equipment_options[] = $row;
    }
    $result->free();
} else {
    echo "Error fetching equipment data: " . $conn->error;
}

// Fetch customer IDs for dropdown
$customer_options = [];
$sql = "SELECT customer_id, name FROM customers";  // Assuming you have a 'customers' table
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $customer_options[] = $row;
    }
    $result->free();
} else {
    echo "Error fetching customer data: " . $conn->error;
}

// Process form data for purchasing specific gym equipment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['purchase_equipment'])) {
    $customer_id = intval($_POST['customer_id']);
    $equipment_id = intval($_POST['equipment_id']);
    $quantity = intval($_POST['quantity']);

    // Ensure quantity is valid
    if ($quantity <= 0) {
        echo "Please enter a valid quantity.";
        exit;
    }

    // Fetch equipment details
    $sql = "SELECT name, price, quantity FROM equipments WHERE equipment_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $stmt->bind_result($equipment_name, $price, $stock);
        $stmt->fetch();
        $stmt->close();

        // Check if equipment exists and there is sufficient stock
        if ($stock !== null) {
            if ($stock >= $quantity) {
                $total_cost = $price * $quantity;

                // Get current date for order_date
                $order_date = date('Y-m-d H:i:s');  // Get current timestamp

                // Insert order into orders table (note the backticks around order to avoid reserved keyword issue)
                $sql = "INSERT INTO orders (customer_id, equipment_id, quantity, total_cost, order_date) VALUES (?, ?, ?, ?, ?)";
                if ($stmt = $conn->prepare($sql)) {
                    $stmt->bind_param("iiids", $customer_id, $equipment_id, $quantity, $total_cost, $order_date);
                    if ($stmt->execute()) {
                        // Update equipment stock
                        $new_stock = $stock - $quantity;  // Corrected line
                        $sql = "UPDATE equipments SET quantity = ? WHERE equipment_id = ?";
                        if ($stmt = $conn->prepare($sql)) {
                            $stmt->bind_param("ii", $new_stock, $equipment_id);
                            if ($stmt->execute()) {
                                echo "Purchase successful! $quantity x $equipment_name bought for $$total_cost.";
                            } else {
                                echo "Error updating stock: " . $stmt->error;
                            }
                            $stmt->close();
                        } else {
                            echo "Error preparing stock update query: " . $conn->error;
                        }
                    } else {
                        echo "Error executing order insert: " . $stmt->error;
                    }
                } else {
                    echo "Error preparing order insert query: " . $conn->error;
                }
            } else {
                // Insufficient stock message
                echo "Insufficient stock for the selected equipment. Available stock: $stock.";
            }
        } else {
            // If equipment does not exist
            echo "Equipment not found.";
        }
    } else {
        echo "Error preparing equipment fetch query: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buy Gym Equipment - FitZone Fitness Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            font-size: 16px;
            color: #333;
        }

        select, input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            width: 100%;
            background-color: blue;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: purple;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Buy Gym Equipment</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label for="customer_id">Customer ID:</label>
                <select id="customer_id" name="customer_id" required>
                    <option value="">Select Customer ID</option>
                    <?php foreach ($customer_options as $customer): ?>
                        <option value="<?php echo $customer['customer_id']; ?>">
                            <?php echo htmlspecialchars($customer['name']) . " (ID: " . $customer['customer_id'] . ")"; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="equipment_id">Equipment:</label>
                <select id="equipment_id" name="equipment_id" required>
                    <option value="">Select Equipment</option>
                    <?php foreach ($equipment_options as $equipment): ?>
                        <option value="<?php echo $equipment['equipment_id']; ?>">
                            <?php echo htmlspecialchars($equipment['name']) . " - $" . $equipment['price']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" required>
            </div>

            <button type="submit" name="purchase_equipment">Purchase</button>
        </form>
    </div>
</body>
</html> 