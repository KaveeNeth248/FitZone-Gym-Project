<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root"; // Change if necessary
$password = ""; // Change if necessary
$dbname = "fit zone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error_message = "";
$success_message = "";

// Handle response update
if (isset($_POST['respond'])) {
    $id = $_POST['id'];
    $response = trim($_POST['response']);
    
    if (!empty($response)) {
        // Update the message with admin's response and mark as read
        $stmt = $conn->prepare("UPDATE messages SET response=?, status='read' WHERE id=?");
        $stmt->bind_param("si", $response, $id);
        if ($stmt->execute()) {
            $success_message = "Response sent successfully.";
            header("Location: ManageMessages.php"); // Refresh page after updating
            exit();
        } else {
            $error_message = "Error updating response: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error_message = "Response cannot be empty.";
    }
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM messages WHERE id=?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $success_message = "Message deleted successfully.";
        header("Location: ManageMessages.php"); // Refresh page after deleting
        exit();
    } else {
        $error_message = "Error deleting message: " . $stmt->error;
    }
    $stmt->close();
}

// Retrieve all messages (with status "unread" by default)
$sql = "SELECT * FROM messages ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Messages - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .message {
            color: red;
            margin-bottom: 20px;
        }
        input, button {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        .button-group {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Manage Messages</h1>

    <!-- Display messages -->
    <?php if (!empty($error_message)): ?>
        <p class="message"><?php echo $error_message; ?></p>
    <?php endif; ?>
    <?php if (!empty($success_message)): ?>
        <p class="message" style="color: green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <!-- Display messages records -->
    <h2>Messages</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo nl2br($row['message']); ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <a href="ManageMessages.php?view_id=<?php echo $row['id']; ?>">View</a> |
                        <a href="ManageMessages.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this message?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No messages found.</td>
            </tr>
        <?php endif; ?>
    </table>

    <!-- Respond to a message (only visible when viewing a message) -->
    <?php if (isset($_GET['view_id'])):
        $view_id = $_GET['view_id'];
        $view_sql = "SELECT * FROM messages WHERE id=?";
        $view_stmt = $conn->prepare($view_sql);
        $view_stmt->bind_param("i", $view_id);
        $view_stmt->execute();
        $view_result = $view_stmt->get_result();
        $message = $view_result->fetch_assoc();
    ?>
        <h2>View and Respond to Message</h2>
        <form method="POST" action="ManageMessages.php">
            <input type="hidden" name="id" value="<?php echo $message['id']; ?>">
            <p><strong>Username:</strong> <?php echo $message['username']; ?></p>
            <p><strong>Email:</strong> <?php echo $message['email']; ?></p>
            <p><strong>Message:</strong></p>
            <p><?php echo nl2br($message['message']); ?></p>
            <label for="response">Response:</label>
            <textarea name="response" id="response" rows="5"><?php echo htmlspecialchars($message['response']); ?></textarea><br><br>
            <button type="submit" name="respond">Send Response</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>