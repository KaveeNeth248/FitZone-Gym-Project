document.getElementById('membershipForm').addEventListener('submit', function(event) {
    event.preventDefault(); 
    // Perform validation or additional logic here if necessary
    alert('Registration submitted!'); 
    this.submit(); 
});

//Fitness Center About
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.querySelector('footer form');
    
    newsletterForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const emailInput = newsletterForm.querySelector('input[type="email"]');
        const email = emailInput.value;

        if (validateEmail(email)) {
            // Here you can add code to send the email to your server
            alert('Thank you for subscribing to our newsletter!');
            emailInput.value = ''; // Clear the input after submission
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        // Simple email validation regex
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
}
});

//Fitness Classes
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.querySelector('.footer form');

    newsletterForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const emailInput = newsletterForm.querySelector('input[type="email"]');
        const email = emailInput.value.trim();

        if (validateEmail(email)) {
            alert('Thank you for subscribing to our newsletter!');
            emailInput.value = ''; // Clear the input after submission
            // Here, you can add code to send the email to your server if needed
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        // Simple regex for basic email validation
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
});

//Fitness Center Blog
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.querySelector('.footer form');

    newsletterForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const emailInput = newsletterForm.querySelector('input[type="email"]');
        const email = emailInput.value.trim();

        if (validateEmail(email)) {
            alert('Thank you for subscribing to our newsletter!');
            emailInput.value = ''; // Clear the input after submission
            // Here you can add code to send the email to your server if needed
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        // Simple regex for basic email validation
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
}
});

//Fitness center Contact
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.querySelector('.contact-form form');

    contactForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const messageInput = document.getElementById('message');

        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const message = messageInput.value.trim();

        if (validateEmail(email) && validateMessage(message)) {
            // Here, you can implement AJAX to send data without refreshing the page or just submit the form
            alert('Thank you, ' + name + '! Your message has been sent successfully.');
            contactForm.reset(); // Clear the form fields
        } else {
            alert('Please ensure all fields are filled out correctly.');
        }
    });

    function validateEmail(email) {
        // Simple regex for basic email validation
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    function validateMessage(message) {
        // Check if message is not just whitespace
        return message.length>0;
}
});

//Fitness Center Services 
document.addEventListener('DOMContentLoaded', function() {
    const serviceCards = document.querySelectorAll('.service-card');
    const newsletterForm = document.getElementById('newsletter-form');

    // Add click event to each service card
    serviceCards.forEach(card => {
        card.addEventListener('click', function() {
            const serviceName = this.querySelector('h3').innerText;
            newFunction(serviceName);
        });

        function newFunction(serviceName) {
            alert(You, clicked, on, $, { serviceName });
        }
    });

    // Handle newsletter form submission
    newsletterForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        const emailInput = newsletterForm.querySelector('input[type="email"]');
        const email = emailInput.value.trim();

      for (let index = 0; index < array.length; index++) {
        const element = array[index];
         array.forEach(_element => {
           if (validateEmail(email)) {
      for (let index = 0; index < array.length; index++) {
         const element = array[index];
}               emailInput.value = ''; // Clear the input field
           } else {
               alert('Please enter a valid email address.');
           }
       
       });
      }
       });
         function validateEmail(email) {
        // Basic regex for email validation
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
});

//Fitness Center Trainers
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn');

    buttons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default action for demonstration
            alert('Booking session for ' + this.closest('.trainer-profile').querySelector('h2').innerText);
    });
});
});